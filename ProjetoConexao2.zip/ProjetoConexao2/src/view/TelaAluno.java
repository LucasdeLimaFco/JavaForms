package view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import controller.AlunoController;

public class TelaAluno extends JFrame {

    private static final long serialVersionUID = 1L;
	private JLabel lblId;
    private JLabel lblNome;
    private JLabel lblEmail;
    private JLabel lblCpf;
    private JLabel lblGenero;
    private JLabel lblDataNascimento;
    private JLabel lblNacionalidade;
    private JLabel lblTelefone;
    private JLabel lblEndereco;
    private JLabel lblCidade;
    private JLabel lblCep;

    private JTextField txtId;
    private JTextField txtNome;
    private JTextField txtEmail;
    private JTextField txtCpf;
    private JTextField txtGenero;
    private JTextField txtDataNascimento;
    private JTextField txtNacionalidade;
    private JTextField txtTelefone;
    private JTextField txtEndereco;
    private JTextField txtCidade;
    private JTextField txtCep;
    
    private JButton btnNovo;
    private JButton btnSalvar;
    private JButton btnExcluir;
    private JButton btnLimpar;

    private JTable tabelaAlunos;
    private DefaultTableModel modeloTabela;

    private AlunoController controller;

    public TelaAluno() {
        setTitle("Cadastro de Clientes - Java SE 7 + Swing + MySQL");
        setSize(900, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        criarComponentes();

        controller = new AlunoController(this);
        configurarEventos();
        controller.carregarTabela();
    }

    private void criarComponentes() {
        JPanel painelFormulario = new JPanel(new GridLayout(11, 2, 10, 10));
        painelFormulario.setBorder(BorderFactory.createTitledBorder("Dados do Cliente"));

        lblId = new JLabel("ID:");
        txtId = new JTextField();
        txtId.setEditable(false);
        
        lblNome = new JLabel("Nome:");
        txtNome= new JTextField();
        
        lblEmail = new JLabel("E-mail:");
        txtEmail = new JTextField();
        
        lblCpf = new JLabel("CPF:");
        txtCpf = new JTextField();

        lblGenero = new JLabel("Gênero:");
        txtGenero = new JTextField();

        lblDataNascimento = new JLabel("Data Nascimento:");
        txtDataNascimento = new JTextField();

        lblNacionalidade = new JLabel("Nacionalidade:");
        txtNacionalidade = new JTextField();

        lblTelefone = new JLabel("Telefone:");
        txtTelefone = new JTextField();

        lblEndereco = new JLabel("Endereço:");
        txtEndereco = new JTextField();

        lblCidade = new JLabel("Cidade:");
        txtCidade = new JTextField();

        lblCep = new JLabel("CEP:");
        txtCep = new JTextField();

        painelFormulario.add(lblId);
        painelFormulario.add(txtId);
        
        painelFormulario.add(lblNome);
        painelFormulario.add(txtNome);
        
        painelFormulario.add(lblEmail);
        painelFormulario.add(txtEmail);
        
        painelFormulario.add(lblCpf);
        painelFormulario.add(txtCpf);

        painelFormulario.add(lblGenero);
        painelFormulario.add(txtGenero);

        painelFormulario.add(lblDataNascimento);
        painelFormulario.add(txtDataNascimento);

        painelFormulario.add(lblNacionalidade);
        painelFormulario.add(txtNacionalidade);

        painelFormulario.add(lblTelefone);
        painelFormulario.add(txtTelefone);

        painelFormulario.add(lblEndereco);
        painelFormulario.add(txtEndereco);

        painelFormulario.add(lblCidade);
        painelFormulario.add(txtCidade);

        painelFormulario.add(lblCep);
        painelFormulario.add(txtCep);

        add(painelFormulario, BorderLayout.NORTH);

        modeloTabela = new DefaultTableModel(new Object[] {
        	    "ID",
        	    "Nome",
        	    "E-mail",
        	    "CPF",
        	    "Genero",
        	    "Data de Nascimento",
        	    "Nacionalidade",
        	    "Telefone",
        	    "Endereço",
        	    "Cidade",
        	    "CEP"
        	    
        	}, 0) {
            private static final long serialVersionUID = 1L;

            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabelaAlunos = new JTable(modeloTabela);
        JScrollPane scrollPane = new JScrollPane(tabelaAlunos);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Lista de Clientes"));
        add(scrollPane, BorderLayout.CENTER);

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));

        btnNovo = new JButton("Novo");
        btnSalvar = new JButton("Salvar");
        btnExcluir = new JButton("Excluir");
        btnLimpar = new JButton("Limpar");

        painelBotoes.add(btnNovo);
        painelBotoes.add(btnSalvar);
        painelBotoes.add(btnExcluir);
        painelBotoes.add(btnLimpar);

        add(painelBotoes, BorderLayout.SOUTH);
    }

    private void configurarEventos() {
        btnNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                controller.limpar();
            }
        });

        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                controller.salvar();
            }
        });

        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                controller.excluir();
            }
        });

        btnLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                controller.limpar();
            }
        });

        tabelaAlunos.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                controller.preencherFormulario();
            }
        });
    }

    public JTextField getTxtId() {
        return txtId;
    }

    public JTextField getTxtNome() {
        return txtNome;
    }

    public JTextField getTxtEmail() {
        return txtEmail;
    }

    public JTable getTabelaAlunos() {
        return tabelaAlunos;
    }
    public JTextField getTxtCpf() {
        return txtCpf;
    }

    public JTextField getTxtGenero() {
        return txtGenero;
    }

    public JTextField getTxtDataNascimento() {
        return txtDataNascimento;
    }

    public JTextField getTxtNacionalidade() {
        return txtNacionalidade;
    }

    public JTextField getTxtTelefone() {
        return txtTelefone;
    }

    public JTextField getTxtEndereco() {
        return txtEndereco;
    }

    public JTextField getTxtCidade() {
        return txtCidade;
    }

    public JTextField getTxtCep() {
        return txtCep;
    }
}

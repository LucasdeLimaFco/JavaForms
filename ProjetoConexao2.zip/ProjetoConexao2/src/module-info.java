/**
 * 
 */
/**
 * 
 */
module ProjetoConexao1 {
	requires java.sql;
	requires java.desktop;
}